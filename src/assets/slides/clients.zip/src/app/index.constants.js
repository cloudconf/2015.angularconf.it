//* global malarkey:false, toastr:false, moment:false */
(function() {
  'use strict';

  angular
    .module('ngconf2015')
    .factory('socket', function(){

      //if(typeof io !== undefined) {
      //  return  io.connect('http://ngtictactoe-53583.onmodulus.net');
        //return io.connect('http://192.168.0.6:4000');
      //}
      return null;
    });
})();
