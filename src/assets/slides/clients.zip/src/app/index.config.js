(function() {
  'use strict';

  angular
    .module('ngconf2015')
    .config(config);

  /** @ngInject */
  function config($logProvider) {
    $logProvider.debugEnabled(true);
  }

})();
