(function() {
  'use strict';

  angular
    .module('ngconf2015')
    .run(runBlock);

  /** @ngInject */
  function runBlock($log) {

    $log.debug('runBlock end');
  }

})();
