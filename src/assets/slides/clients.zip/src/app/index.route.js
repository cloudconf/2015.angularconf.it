(function() {
  'use strict';

  angular
    .module('ngconf2015')
    .config(routeConfig);

  /** @ngInject */
  function routeConfig($urlRouterProvider) {
    $urlRouterProvider.otherwise('/home');
  }

})();
