(function () {
  'use strict';

  angular
    .module('ngconf2015')
    .controller('MainGameController', MainGameController);

  function MainGameController() {
    //var vm = this;
  }
})();
