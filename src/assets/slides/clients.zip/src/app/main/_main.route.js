(function() {
  'use strict';

  angular
    .module('ngconf2015')
    .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
      .state('home', {
        url: '/home',
        templateUrl: 'app/main/home.html',
        controller: 'MainHomeController',
        controllerAs: 'vm'
      }).state('game', {
        url: '/game',
        templateUrl: 'app/main/game.html',
        controller: 'MainGameController',
        controllerAs: 'vm'
      });
  }

})();
