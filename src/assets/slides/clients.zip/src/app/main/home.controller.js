(function () {
  'use strict';

  angular
    .module('ngconf2015')
    .controller('MainHomeController', MainHomeController);

  function MainHomeController($timeout, $state) {
    var vm = this;
    vm.gotoGame = gotoGame;

    vm.wait = true;

    $timeout(function(){
      vm.wait = false;
    }, 3000);


    function gotoGame(){
      if(!vm.wait) {
        $state.go("game");
      }
    }
  }
})();
