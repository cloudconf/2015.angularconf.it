(function() {
  'use strict';

  angular
    .module('ngconf2015', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize',
      'ui.router', 'ui.bootstrap'
    ]);
})();
