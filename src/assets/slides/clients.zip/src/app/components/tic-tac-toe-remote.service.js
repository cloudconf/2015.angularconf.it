(function () {
  'use strict';

  angular
    .module('ngconf2015')
    .factory('TicTacToeRemoteService', TicTacToeRemoteService);


  function TicTacToeRemoteService($rootScope, socket) {
    var myTeam;

    var service       = $rootScope.$new(true);
    service.init      = init;
    service.getState  = getState;
    service.tryMove   = tryMove;
    service.checkWin  = function(){};
    service.newGame   = newGame;

    return service;

    function init(){
      socket.on('connected', function (data) {
        alert("JOINED TEAM " + JSON.stringify(data.team));
        $rootScope.$apply(function(){
          myTeam = data.team;
        });
      });

      socket.on("start", function(state){
        $rootScope.$apply(function() {
          state.team = myTeam;
          service.$broadcast("start", state);
        });
      });

      socket.on("new-move", function(state){
        $rootScope.$apply(function() {
          service.$broadcast("new-move", state);
        });
      });


      socket.on("new-turn", function(state){
        $rootScope.$apply(function() {
          service.$broadcast("new-turn", state);
        });
      });

      socket.on("wrong-move", function(state){
        $rootScope.$apply(function() {
          service.$broadcast("wrong-move", state);
        });
      });

      socket.on("end", function(state){
        $rootScope.$apply(function() {
          service.$broadcast("end", state);
        });
      });

      socket.on("tie", function(state){
        $rootScope.$apply(function() {
          service.$broadcast("tie", state);
        });
      });
    }


    function getState(){}

    function tryMove(move){
      move.player = myTeam;
      socket.emit("try-move", move);
      // devo aggiungere la mia squadra

    }

    function newGame(){}
  }
})
();
