(function () {
  'use strict';

  angular
    .module('ngconf2015')
    .factory('TicTacToeService', TicTacToeService);

  function TicTacToeService($log, $rootScope, $timeout) {
    var state;
    var service       = $rootScope.$new(true);
    service.init      = init;
    service.getState  = getState;
    service.tryMove   = tryMove;
    service.checkWin  = checkWin;
    service.newGame   = newGame;

    return service;

    function init(){
      state = {
        currentPlayer : null,
        score : [0,0]
      };
      newGame();
    }

    function newGame(){
      state.state = 'WAIT-MOVE';
      state.board = [[null, null, null],[null, null, null],[null, null, null]];
      if(state.currentPlayer !== null){
        state.currentPlayer = (state.currentPlayer + 1) % 2;
      }else{
        state.currentPlayer = 0;
      }
      service.$broadcast("start", angular.copy(state) );
    }

    function getState(){
      return state;
    }

    function tryMove(move){
      if(state.state !== 'WAIT-MOVE'){
        service.$broadcast('wrong-move',{
          move : move,
          currentState : angular.copy(state)
        });
      }else if(move.player !== state.currentPlayer || state.board[move.row][move.column] !== null){
        service.$broadcast('wrong-move',{
          move : move,
          currentState : angular.copy(state)
        });
      }else{
        state.board[move.row][move.column] = state.currentPlayer;
        state.state = 'NEW-TURN';
        service.$broadcast('new-move',{
          move : move,
          currentState : angular.copy(state)
        });

        $timeout(function(){
          if(checkWin()){
            state.score[state.currentPlayer]++;
            state.state = 'END';
            service.$broadcast('end',{
              currentState : angular.copy(state)
            });
          }else if(checkTie()){
            state.state = 'TIE';
            service.$broadcast('tie',{
              move : move,
              currentState : angular.copy(state)
            });
          }else{
            state.state = 'WAIT-MOVE';
            state.currentPlayer = (state.currentPlayer + 1) % 2;
            service.$broadcast('new-turn',{
              move : move,
              currentState : angular.copy(state)
            });
          }
        }, 500);
      }
    }

    function checkTie(){
      if(checkWin()) {
        return false;
      }
      return !(_.contains(_.flatten(state.board), null));

    }

    function checkWin(){
      var player = state.currentPlayer;
      if(
      /* orizzontali */
        state.board[0][0] === player && state.board[0][1] === player && state.board[0][2] === player
        ||
        state.board[1][0] === player && state.board[1][1] === player && state.board[1][2] === player
        ||
        state.board[2][0] === player && state.board[2][1] === player && state.board[2][2] === player
        ||
      /* verticali */
        state.board[0][0] === player && state.board[1][0] === player && state.board[2][0] === player
        ||
        state.board[0][1] === player && state.board[1][1] === player && state.board[2][1] === player
        ||
        state.board[0][2] === player && state.board[1][2] === player && state.board[2][2] === player
        ||
      /* diagonali */
        state.board[0][0] === player && state.board[1][1] === player && state.board[2][2] === player
        ||
        state.board[0][2] === player && state.board[1][1] === player && state.board[2][0] === player
      ){
        return true;
      }
      return false;
    }
  }
})
();
