(function () {
  "use strict";
  angular
    .module('ngconf2015')
    .directive('ticTacToeBoard', ticTacToeBoard);

  function ticTacToeBoard($log, TicTacToeService, TicTacToeRemoteService) {
    return {
      restrict: 'A',
      link : link
    };

    function link(scope, element, attrs) {
      var service;

      element.on('$destroy', function() {
        /* cleanup */
      });

      if(attrs.remote && attrs.remote === 'true'){
        service = TicTacToeRemoteService;
        scope.remote = true;
      }else{
        service = TicTacToeService;
      }

      scope.tictactoe = {};
      /* property */
      scope.tictactoe.currentState = null;

      /* methods */
      scope.tictactoe.newGame = newGame;
      scope.tictactoe.tryMove = tryMove;
      scope.tictactoe.initGame = initGame;
      initGame();
      service.init();


      function tryMove(row, column){
        var move = {
          row : row,
          column : column
        };

        if(!scope.remote){
          move.player = scope.tictactoe.currentState.currentPlayer;
        }

        service.tryMove(move);
      }
      function newGame(){
        if(!scope.remote){
          TicTacToeService.newGame();
        }
      }

      function initGame(){
        service.$on("start", function(event, currentState){
          scope.tictactoe.team = currentState.team;
          scope.tictactoe.currentState = angular.copy(currentState);
          $log.debug("game start, current state", scope.tictactoe.currentState);
        });

        service.$on("new-move", function(event, data){
          scope.tictactoe.currentState = data.currentState;
        });

        service.$on("new-turn", function(event, data){
          scope.tictactoe.currentState = data.currentState;
        });


        service.$on("wrong-move", function(event, data){
          //window.alert("Wrong move");
          scope.tictactoe.currentState = data.currentState;
        });

        service.$on("end", function(event, data){
          scope.tictactoe.currentState = data.currentState;
        });

        service.$on("tie", function(event, data){
          scope.tictactoe.currentState = data.currentState;
        });

      }
    }
  }

})
();
