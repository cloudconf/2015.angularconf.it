//var io = require('socket.io')(8180);
var io = require('socket.io')(4000);
var _ = require("underscore");
var players = {};
var currentMoves = {};
var gameStarted = false;
var state;


io.on('connection', function (socket) {
  socket.team = (_.keys(players).length + 1) % 2;
  players[socket.id] = socket;
  console.log("client connected, team ", socket.team);

  console.log({ team : socket.team });
  socket.emit('connected', { team : socket.team });

  console.log(_.keys(players).length, "players");
  if(_.keys(players).length >= 2 && !gameStarted) {
    newGame();
  }

  socket.on('disconnect', function () {
    players = _.omit(players, socket.id);
    console.log("client disconnected");
    console.log(_.keys(players).length, "players");
  });

  socket.on('try-move', function (move) {
    console.log(socket.team, move);

    if(state.state !== 'WAIT-MOVE'){
      console.log("non è il momento di giocare", state);
      socket.emit('wrong-move',{
        move          : move,
        currentState  : state
      });
    }else if(move.player !== state.currentPlayer || state.board[move.row][move.column] !== null){
      console.log(move.player, state.currentPlayer, "non toccava a te o la cella era già occupata");
      socket.emit('wrong-move',{
        move          : move,
        currentState  : state
      });
    }else{
      console.log("mossa corretta, la registro");
      delete move.player;
      currentMoves[socket.id] = move;
    }
  });
});

init();



function init(){
  console.log("init");
  state = {
    currentPlayer : null,
    score : [0,0]
  };
}


function newGame(){
  if(gameStarted)
    return;
  gameStarted = true;
  console.log("newGame");
  state.state = 'WAIT-MOVE';
  state.board = [[null, null, null],[null, null, null],[null, null, null]];
  if(state.currentPlayer !== null){
    state.currentPlayer = (state.currentPlayer + 1) % 2;
  }else{
    state.currentPlayer = 1;
  }
  waitMove();
  io.emit("start", state );

}

function waitMove(){
  currentMoves = [];
  console.log("wait move, tocca a ", state.currentPlayer);
  setTimeout(function(){
    var move;
    console.log("tempo scaduto, mosse registrate ", currentMoves);

    move = pickMove(currentMoves);
    console.log("selezionata la mossa, " , move);
    state.board[move.row][move.column] = state.currentPlayer;
    state.state = 'NEW-TURN';
    io.emit('new-move',{ move : move, currentState : state});

    setTimeout(function(){
      if(checkWin()){
        console.log("Vincitore");
        state.score[state.currentPlayer]++;
        state.state = 'END';
        io.emit('end',{
          currentState : state
        });
        setTimeout(function(){
          gameStarted = false;
          newGame();
        }, 1000);
      }else if(checkTie()){
        console.log("Pari");
        state.state = 'TIE';
        io.emit('tie',{
          move : move,
          currentState : state
        });
        setTimeout(function(){
          gameStarted = false;
          newGame();
        }, 1000);
      }else{
        console.log("nessun vincitore, passo al prossimo turno")
        state.state = 'WAIT-MOVE';
        state.currentPlayer = (state.currentPlayer + 1) % 2;
        io.emit('new-turn',{
          move : move,
          currentState : state
        });
        waitMove();
      }
    }, 2 * 1000);
  }, 8 * 1000);
}


function pickMove(currentMoves){
  console.log("mosse fatte?", currentMoves);
  if(_.values(currentMoves).length === 0){
    for(var r = 0; r < 3; r++){
      for(var c = 0; c < 3; c++){
        if(state.board[r][c] === null){
          console.log("faccio questa");
          return {
            row : r,
            column : c
          }
        }
      }
    }
  }

  // TODO: selezionare la mossa con selezioni più alte, al momento seleziono semprela prima in ordine di arrivo :(
  return _.values(currentMoves)[0];
}


function checkTie(){
  if(checkWin())
    return false;
  return !(_.contains(_.flatten(state.board), null));

}

function checkWin(){
  var player = state.currentPlayer;
  if(
    /* orizzontali */
  state.board[0][0] === player && state.board[0][1] === player && state.board[0][2] === player
  ||
  state.board[1][0] === player && state.board[1][1] === player && state.board[1][2] === player
  ||
  state.board[2][0] === player && state.board[2][1] === player && state.board[2][2] === player
  ||
    /* verticali */
  state.board[0][0] === player && state.board[1][0] === player && state.board[2][0] === player
  ||
  state.board[0][1] === player && state.board[1][1] === player && state.board[2][1] === player
  ||
  state.board[0][2] === player && state.board[1][2] === player && state.board[2][2] === player
  ||
    /* diagonali */
  state.board[0][0] === player && state.board[1][1] === player && state.board[2][2] === player
  ||
  state.board[0][2] === player && state.board[1][1] === player && state.board[2][0] === player
  ){
    return true;
  }
  return false;
}
